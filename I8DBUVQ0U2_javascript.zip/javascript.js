function maximizeExpr(a , n , x , y , z)
    {
        var L = Array(n).fill(0);
        L[0] = x * a[0];
        for (i = 1; i < n; i++)
            L[i] = Math.max(L[i - 1], x * a[i]);
        var R = Array(n).fill(0);
        R[n - 1] = z * a[n - 1];
        for (i = n - 2; i >= 0; i--)
            R[i] = Math.max(R[i + 1], z * a[i]);
        var ans = Number.MIN_VALUE;
        for (i = 0; i < n; i++)
            ans = Math.max(ans, L[i] + y * a[i] + R[i]);
 
        return ans;
    }
        var a = [ -1, -2, -3, -4, -5 ];
        var n = a.length;
        var x = 1, y = 2, z = -3;
        document.write(maximizeExpr(a, n, x, y, z));